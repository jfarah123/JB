using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyFirstMeme
{
    public partial class Form1 : Form
    {
         OpenFileDialog openImage;
        string imageFile;
        public Form1()
        {
            InitializeComponent();
        }

        private void imagePanel1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap b = new Bitmap(openFileDialog1.FileName);
               imagePanel1.CanvasSize = b.Size;
                imagePanel1.Image = b;
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            imagePanel1.Zoom = trackBar1.Value * 0.02f;
        }

        private void MultiplePictures_Click(object sender, EventArgs e)
        {
            openImage = new OpenFileDialog();
            openImage.Title = "Select mulitple images";
            openImage.Multiselect = true;
            openImage.InitialDirectory = "c:\\";
            openImage.Filter =
                "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png; *.gif; *.bmp";
            openImage.FilterIndex = 2;
            openImage.RestoreDirectory = true;

            if (openImage.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] files = openImage.FileNames;
                    int x = 100;
                    int y = 100;
                    int maxHeight = -1;
                    foreach (var images in files)
                    {
                        PictureBox pic = new PictureBox();
                        pic.Image = Image.FromFile(images);
                        pic.Location = new Point(x, y);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        x += pic.Width + 100;
                        maxHeight = Math.Max(pic.Height, maxHeight);
                        if (x > this.ClientSize.Width - 100)
                        {
                            x = 20;
                            y += maxHeight;
                        }
                        //imagePanel1.CanvasSize = b.Size;
                        Bitmap b = new Bitmap(images);
                        imagePanel1.Image = b;
                        this.imagePanel1.Controls.Add(pic);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            imagePanel1.Zoom = trackBar1.Value * 0.02f;
            imagePanel1.Controls.Clear(); 
        }

        }
    }
