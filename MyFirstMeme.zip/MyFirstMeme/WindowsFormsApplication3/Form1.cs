﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace memeMaker
{
    public partial class Form1 : Form
    {
        OpenFileDialog openImage;
        string imageFile;

        public Form1()
        {
            InitializeComponent();
            Controll();

        }

        public void Controll()
        {

            hScrollBar1.Width = preview.Width;
            hScrollBar1.Left = preview.Left;
            hScrollBar1.Top = preview.Bottom;
            if (preview.Image!=null)
            hScrollBar1.Maximum = preview.Image.Width - preview.Width;

            hScrollBar1.Height = preview.Height;
            hScrollBar1.Left = preview.Left + preview.Width;
            hScrollBar1.Top = preview.Top;

            if (preview.Image != null)
            hScrollBar1.Maximum = preview.Image.Height - preview.Height;

          
        }
        private void topText_TextChanged_1(object sender, EventArgs e)
        {
            topLabel.Text = "My Internet Meme Catalog";
            topLabel.MaximumSize = new Size(preview.Width, 200);
        }

        private void bottomLabel_TextChanged(object sender, EventArgs e)
        {
            bottomText.Text = "Internet Meme Catalog";
            bottomText.MaximumSize = new Size(preview.Width, 200);
        }

        private void open_Click_1(object sender, EventArgs e)
        {
            openImage = new OpenFileDialog();
            openImage.Title = "Select mulitple images";
            openImage.Multiselect = true;
            openImage.InitialDirectory = "c:\\";
            openImage.Filter =
                "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png; *.gif; *.bmp";
            openImage.FilterIndex = 2;
            openImage.RestoreDirectory = true;

            if (openImage.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] files = openImage.FileNames;
                    int x = 100;
                    int y = 100;
                    int maxHeight = -1;
                    foreach (var images in files)
                    {
                        PictureBox pic = new PictureBox();
                        pic.Image = Image.FromFile(images);
                        pic.Location = new Point(x, y);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        x += pic.Width + 100;
                        maxHeight = Math.Max(pic.Height, maxHeight);
                        if (x > this.ClientSize.Width - 100)
                        {
                            x = 20;
                            y += maxHeight;
                        }
                        this.preview.Controls.Add(pic);
                    }

                    //preview.Image = Image.FromFile(openImage.FileName);
                    //imageFile = openImage.FileName;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void Save_Click_1(object sender, EventArgs e)
        {
            string firstText = bottomText.Text;
            string secondText = bottomText.Text;

            if (openImage != null) { 
            string[] files = openImage.FileNames;

                foreach (var images in files)
                {
                    Bitmap bitmap = (Bitmap) Image.FromFile(images); //load the image file
                    RectangleF TopSize = new RectangleF(0, 10, bitmap.Width, 400);
                    RectangleF BottomSize = new RectangleF(0, bitmap.Height - 100, bitmap.Width, 400);
                    SaveFileDialog saveImage = new SaveFileDialog();
                    saveImage.FileName = "*";
                    saveImage.DefaultExt = "bmp";
                    saveImage.ValidateNames = true;
                    saveImage.Filter = "Bitmap Image (.bmp)|*.bmp|Gif Image (.gif)|*.gif |JPEG Image (.jpg)|*.jpeg |Png Image (.png)|*.png";
                    if (saveImage.ShowDialog() == DialogResult.OK)
                    {
                        using (Graphics graphics = Graphics.FromImage(bitmap))
                        {
                            using (Font memeFont = new Font("Impact", 24, FontStyle.Bold, GraphicsUnit.Point))
                            {
                                graphics.DrawString(firstText, memeFont, Brushes.White, TopSize);
                                graphics.DrawString(secondText, memeFont, Brushes.White, BottomSize);
                            }
                        }
                        bitmap.Save(saveImage.FileName); //save the image file
                    }
                }
            }
        }

        private void RemoveImges_Click(object sender, EventArgs e)
        {    
           
            this.preview.Controls.Clear(); 
  
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            preview.SizeMode = PictureBoxSizeMode.AutoSize;
            //Panel MyPanel = new Panel();
            //PictureBox pictureBox1 = new PictureBox();

            Image image = Image.FromFile("image.png");

            preview.Image = image;
            preview.Height = image.Height;
            preview.Width = image.Width;

            preview.Controls.Add(preview);
           // preview.AutoScroll = true;
            this.Controls.Add(preview);
            Controll();
        }
        int x = 0;
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            x = (sender as HScrollBar).Value;
            preview.Refresh();
        }
        int y = 1;
        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            y = (sender as VScrollBar).Value;
            preview.Refresh();
        }

        private void pictureBox1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            var pBox = sender as PictureBox;
            e.Graphics.DrawImage(pBox.Image, e.ClipRectangle, x, y, e.ClipRectangle.Width,
              e.ClipRectangle.Height, GraphicsUnit.Pixel);
        }
    }
}


